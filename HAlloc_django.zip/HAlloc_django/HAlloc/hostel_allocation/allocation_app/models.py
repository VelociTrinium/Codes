# from django.db import models

# class Preference(models.Model):
#     student_id = models.CharField(max_length=20, unique=True)
#     preferences = models.JSONField()  # Stores multiple preferences

#     def __str__(self):
#         return f"Preferences of {self.student_id}"


