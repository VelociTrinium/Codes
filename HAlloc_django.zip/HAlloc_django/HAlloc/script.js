<script>
    function toggleSidebar() {
        document.getElementById("sidebar").classList.toggle("expanded");
    }

    function navigateTo(page) {
        window.location.href = page;
    }
</script>
